package com.algaworks.wine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WineApplication {

	public static void main(String[] args) {
		SpringApplication.run(WineApplication.class, args);
	}
}
