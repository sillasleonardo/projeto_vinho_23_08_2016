package com.algaworks.wine.storage;

public interface FotoReader {
	
	public byte[] recuperar(String nome);

}
